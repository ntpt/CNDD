package com.example.calculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.calculator.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    private Button btnCal0;
    private Button btnCal1;
    private Button btnCal2;
    private Button btnCal3;
    private Button btnCal4;
    private Button btnCal5;
    private Button btnCal6;
    private Button btnCal7;
    private Button btnCal8;
    private Button btnCal9;
    private Button btnCalPlus;
    private Button btnCalMinus;
    private Button btnCalMul;
    private Button btnCalDivide;
    private Button btnCalMod;
    private Button btnCalClear;
    private Button btnCalEqual;
    private Button btnCalDot;
    private EditText editTextInput;
    private TextView textViewResult;
    private String firstValue = "";
    private String secondValue = "";
    private String currentOperation;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnCal0 = (Button) view.findViewById(R.id.btnCal0);
        btnCal1 = (Button) view.findViewById(R.id.btnCal1);
        btnCal2 = (Button) view.findViewById(R.id.btnCal2);
        btnCal3 = (Button) view.findViewById(R.id.btnCal3);
        btnCal4 = (Button) view.findViewById(R.id.btnCal4);
        btnCal5 = (Button) view.findViewById(R.id.btnCal5);
        btnCal6 = (Button) view.findViewById(R.id.btnCal6);
        btnCal7 = (Button) view.findViewById(R.id.btnCal7);
        btnCal8 = (Button) view.findViewById(R.id.btnCal8);
        btnCal9 = (Button) view.findViewById(R.id.btnCal9);
        btnCalPlus = (Button) view.findViewById(R.id.btnCalPlus);
        btnCalMinus = (Button) view.findViewById(R.id.btnCalMinus);
        btnCalMul = (Button) view.findViewById(R.id.btnCalMul);
        btnCalDivide = (Button) view.findViewById(R.id.btnCalDivide);
        btnCalClear = (Button) view.findViewById(R.id.btnCalClear);
        btnCalEqual = (Button) view.findViewById(R.id.btnCalEqual);
        btnCalDot = (Button) view.findViewById(R.id.btnCalDot);
        btnCalMod = (Button) view.findViewById(R.id.btnCalMod);
        editTextInput = (EditText) view.findViewById(R.id.editTextInput);
        textViewResult = (TextView) view.findViewById(R.id.textViewResult);

        btnCal0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "0");
            }
        });

        btnCal0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "0");
            }
        });

        btnCal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "1");
            }
        });

        btnCal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "2");
            }
        });

        btnCal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "3");
            }
        });

        btnCal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "4");
            }
        });

        btnCal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "5");
            }
        });

        btnCal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "6");
            }
        });

        btnCal7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "7");
            }
        });

        btnCal8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "8");
            }
        });

        btnCal9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + "9");
            }
        });

        btnCalDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String currentValue = editTextInput.getText().toString();
                editTextInput.setText(currentValue + ".");
            }
        });

        btnCalPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentOperation = "+";
                firstValue = editTextInput.getText().toString();
                editTextInput.setText("");
            }
        });

        btnCalMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentOperation = "-";
                firstValue = editTextInput.getText().toString();
                editTextInput.setText("");
            }
        });

        btnCalMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentOperation = "*";
                firstValue = editTextInput.getText().toString();
                editTextInput.setText("");
            }
        });

        btnCalDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentOperation = "/";
                firstValue = editTextInput.getText().toString();
                editTextInput.setText("");
            }
        });

        btnCalMod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                currentOperation = "%";
                firstValue = editTextInput.getText().toString();
                editTextInput.setText("");
            }
        });

        btnCalClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextInput.setText("");
                firstValue = "";
                secondValue = "";
            }
        });

        btnCalEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                secondValue = editTextInput.getText().toString();
                Float finalResult = null;
                if(currentOperation == "+") {
                    finalResult = Float.parseFloat(firstValue) + Float.parseFloat(secondValue);
                }
                if(currentOperation == "-") {
                    finalResult = Float.parseFloat(firstValue) - Float.parseFloat(secondValue);
                }
                if(currentOperation == "*") {
                    finalResult = Float.parseFloat(firstValue) * Float.parseFloat(secondValue);
                }
                if(currentOperation == "/") {
                    finalResult = Float.parseFloat(firstValue) / Float.parseFloat(secondValue);
                }
                if(currentOperation == "%") {
                    finalResult = Float.parseFloat(firstValue) % Float.parseFloat(secondValue);
                }
                textViewResult.setText(firstValue.toString() + currentOperation + secondValue.toString() + " = " + finalResult);
                editTextInput.setText("");
                firstValue = "";
                secondValue = "";
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}